﻿namespace Server.Models.DTOs
{
    public class ImageUpload
    {        public string ImgName { get; set; }
    }
}
